#include "ros/ros.h"
#include<cmath>
#include <iostream>
#include<fstream>
#include<opencv2/core/core.hpp>
#include<opencv2/highgui/highgui.hpp>
#include<opencv2/imgproc/imgproc.hpp>
#include "pcl_ros/point_cloud.h"
#include "pcl/point_types.h"
#include <chrono>
#include <pcl_ros/transforms.h>
#include <pcl_conversions/pcl_conversions.h>
#include <tf/transform_listener.h>
#include <std_msgs/String.h>
#include <sensor_msgs/point_cloud_conversion.h>
#include <sensor_msgs/LaserScan.h>
#include<sensor_msgs/Imu.h>
#include<nav_msgs/Odometry.h>
#include<people_msgs/People.h>
#include<people_msgs/Person.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <queue>
#include <geometry_msgs/Point.h>
#include<std_msgs/Float64.h>
int M,HZctrl;
#define MAP_IDX(sx, i, j) ((sx) * (i+M) + (j))
#define PI 3.14159265
using namespace std;
using namespace cv;

class PointcloudObstacle
{
private:




    int16_t get_median_num(int16_t* num_array, int len){
        int     i,j;            // 循环变量
        int16_t num_temp;
        // 用冒泡法对数组进行排序
        for (j = 0; j < len - 1; j ++)
        {
            for (i = 0; i < len - j - 1; i ++)
            {
                if (num_array[i] > num_array[i + 1])
                {
                    // 互换
                    num_temp = num_array[i];
                    num_array[i] = num_array[i + 1];
                    num_array[i + 1] = num_temp;
                }
            }
        }
        // 返回中间一个元素
        num_temp = num_array[len / 2];
        return num_temp;
    }

    tf::TransformListener listener;
    tf::Transform Tftran;




    ros::Timer timer;

    double max_observable_distance;
    double max_grad;//梯度差阈值，单位cm
    double resolution_z;//z分辨率,单位m
    double resolution_xy;//xy分辨率,单位m
    double min_elevation;//最小高度
    double max_elevation;//最大高度
    std::vector<int16_t> elevation_data;//高度地图
    std::vector<int16_t> temp_data;//高度地图缓存
    std::vector<int16_t> last_temp_data;//上一帧高度地图缓存
    int isFirstMap=0;
    int width;//地图的宽，单位m
    int width_half;
    int height;//地图的长，单位m
    int height_half;
    int unknown_elevation;
    int median_filter_size;
    int isolation_filter_threshold;
    int connection_filter_threshold;
    int search_size;
    static bool IsDownhill=false;
    cv::Mat LastMap,CurrentMap;
    sensor_msgs::PointCloud obstacle_points;
    people_msgs::People po_people;
    people_msgs::Person po_person;
    chrono::steady_clock::time_point t1;
    chrono::steady_clock::time_point t0;
    float timeT;
    std::string local_map_frame_id;
    std::string point_cloud_topic;
    std::string imu_topic;
    std::string car_speed_topic;
    //std::string people_topic;
    std::string position_topic;

    ros::Publisher pub_points;
    ros::Publisher pub_scan;
    ros::Publisher pub_people;

    ros::Subscriber sub_pointCloud;
    ros::Subscriber sub_position;
    //ros::Subscriber sub_imu;
    //ros::Subscriber sub_vel;

public:
    /// Default plugin constructor
    PointcloudObstacle(){

        ros::NodeHandle nPrivateHandle("~");//前面加name空间
        nPrivateHandle.param<double>("elevation_resolution", resolution_z, 0.01); //[m]
        nPrivateHandle.param<double>("max_observable_distance", max_observable_distance, 10.0); //[m]
        nPrivateHandle.param<int>("unknown_elevation", unknown_elevation, -100); //[cell]
        nPrivateHandle.param<double>("min_observable_elevation", min_elevation, -1.00); //[m]
        nPrivateHandle.param<double>("max_observable_elevation", max_elevation, 1.00); //[m]
        nPrivateHandle.param<double>("map_resolution", resolution_xy, 0.05); //[m]
        nPrivateHandle.param<int>("max_grid_size_x", width, 200); //[cell]
        nPrivateHandle.param<bool>("IsDownhill", IsDownhill, false); //[bool]
        width_half = width/2;
        nPrivateHandle.param<int>("max_grid_size_y", height, 200); //[cell]
        nPrivateHandle.param<int>("search_size", search_size, 20); //[cell]
        M = search_size;
        nPrivateHandle.param<int>("median_filter_size", median_filter_size, 1); //[cell]
        nPrivateHandle.param<int>("isolation_filter_threshold", isolation_filter_threshold, 3); //[cell]
        nPrivateHandle.param<int>("connection_filter_threshold", connection_filter_threshold, 8); //[cell]
        nPrivateHandle.param<double>("max_grad", max_grad, 10.0); //[cm]
        nPrivateHandle.param<std::string>("local_map_frame_id", local_map_frame_id,std::string("base_link"));
        nPrivateHandle.param<std::string>("point_cloud_topic", point_cloud_topic, std::string("points"));
        nPrivateHandle.param<std::string>("position_topic", position_topic, std::string("/odometry/filtered/global"));
        //nPrivateHandle.param<std::string>("car_speed_topic", car_speed_topic, std::string("odom"));
        //nPrivateHandle.param<std::string>("imu_topic", imu_topic, std::string("compensated_imu"));        
        elevation_data = std::vector<int16_t>(width * height,(int16_t)unknown_elevation);
        temp_data = std::vector<int16_t>(width * height,(int16_t)unknown_elevation);
        last_temp_data = std::vector<int16_t>(width * height,(int16_t)unknown_elevation);
        sub_pointCloud = nPrivateHandle.subscribe(point_cloud_topic,1,&PointcloudObstacle::cloudCallback,this);
        sub_position = nPrivateHandle.subscribe(position_topic,1,&PointcloudObstacle::positionCallback,this);
        pub_points = nPrivateHandle.advertise<sensor_msgs::PointCloud>("obstacle_points", 1, true);
        pub_scan = nPrivateHandle.advertise<sensor_msgs::LaserScan>("obstacle_scan",1,true);
        pub_people = nPrivateHandle.advertise<people_msgs::People>("obstacle_people",1,true);
        LastMap=cv::Mat::zeros(height,width,CV_8UC1);
        CurrentMap=cv::Mat::zeros(height,width,CV_8UC1);
        ROS_INFO("P_O: is up and running.");
        HZctrl=0;
    }

    /// Default deconstructor
    ~PointcloudObstacle(){
        ROS_INFO("P_O: Shutting down!");

    }

    /// cloudCallback get called if a new 3D point cloud is avaible
    /**
    * \param [in] pointcloud2_sensor_msg contains the 3D point cloud
    */
    void positionCallback(const nav_msgs::OdometryConstPtr& position_sensor_msg){
        double positionx,positiony;
        positionx=position_sensor_msg->pose.pose.position.x;
        positiony=position_sensor_msg->pose.pose.position.y;
        if(0){
            IsDownhill=true;
            return;
        }
        IsDownhill=false;

    }
    void cloudCallback(const sensor_msgs::PointCloud2ConstPtr& pointcloud2_sensor_msg){
            if(HZctrl==1) {
                HZctrl=0;
                return;
            }
            HZctrl++;

            pcl::PointCloud<pcl::PointXYZ>::Ptr pointcloud2_map_pcl (new pcl::PointCloud<pcl::PointXYZ>()),
            pointcloud2_sensor_pcl (new pcl::PointCloud<pcl::PointXYZ> ());
            obstacle_points.points.clear();
            geometry_msgs::Point32 point;
            // converting PointCloud2 msg format to pcl pointcloud format in order to read the 3d data

            pcl::fromROSMsg(*pointcloud2_sensor_msg, *pointcloud2_sensor_pcl);


            // transform cloud to /base_link frame
            try
            {
                //listener.waitForTransform(local_map_frame_id, pointcloud2_sensor_msg->header.frame_id,ros::Time::now(),ros::Duration(1.0));
                listener.waitForTransform(local_map_frame_id, pointcloud2_sensor_msg->header.frame_id,pointcloud2_sensor_msg->header.stamp,ros::Duration(1.0));
                pcl_ros::transformPointCloud(local_map_frame_id,*pointcloud2_sensor_pcl,*pointcloud2_map_pcl,listener);
            }
            catch (tf::TransformException ex)
            {
                ROS_ERROR("%s",ex.what());
                return;
            }
            //清空原图
            elevation_data = std::vector<int16_t>(width * height, (int16_t)unknown_elevation);//创建空地图vector
            unsigned int size = (unsigned int)pointcloud2_map_pcl->points.size();
            if( size == pointcloud2_map_pcl->width * pointcloud2_map_pcl->height && size>0)
            {
                // iterate trough all points
                for (unsigned int k = 0; k < size; ++k)
                {


                    const pcl::PointXYZ& pt_cloud = pointcloud2_map_pcl->points[k];
                    double measurement_distance = pointcloud2_sensor_pcl->points[k].z;

                    // check for invalid measurements
                    if (isnan(pt_cloud.x) || isnan(pt_cloud.y) || isnan(pt_cloud.z))
                        continue;
                    // check max distance
                    if( measurement_distance > max_observable_distance || measurement_distance < 0.3)
                        continue;
                    // check min/max height   pt_cloud是base_link坐标系下的点云；
                    if( pt_cloud.z < min_elevation || pt_cloud.z > max_elevation)
                        continue;

                    // allign grid points
                    int cell_index = MAP_IDX(width,
                      (int)round(pt_cloud.x/resolution_xy),
                      (int)round(pt_cloud.y/resolution_xy)+width_half);

                    if(cell_index >= width*height) continue;//

                    int16_t* pt_local_map = &elevation_data[cell_index];
                    // elevation in current cell in meter
                    double cell_elevation = resolution_z*(*pt_local_map);
                    // store maximum of each cell
                    if(pt_cloud.z > cell_elevation)
                    {
                        *pt_local_map = (int16_t)round(pt_cloud.z/resolution_z);
                    }
                }




                int m = M-1;
                bool x_unknown = false;
                bool y_unknown = false;
                bool xy_unknown = false;
                bool yx_unknown = false;

                // median filter
                if(1)
                {
                    temp_data = elevation_data;
                    int N = median_filter_size; // N=2 -> 5*5    N=1 -> 3*3
                    int len = (N*2+1)*(N*2+1);
                    int16_t elevation_array[len] = {0};
                    int16_t temp_elevation = unknown_elevation;
                    for (int index_y = M; index_y < (int)(width-M); ++index_y)
                    {
                        for (int index_x = 0; index_x < (int)(height-2*M); ++index_x)
                        {
                            if(temp_data[MAP_IDX(width,index_x,index_y)] == unknown_elevation)
                                continue;
                            int k = 0;
                            for(int i = index_x-N;i <= index_x+N;i++)
                            {
                                for(int j = index_y-N;j <= index_y+N;j++)
                                {
                                    elevation_array[k] = temp_data[MAP_IDX(width,i,j)];
                                    k++;
                                }
                            }
                            temp_elevation = get_median_num(elevation_array,len);
                            elevation_data[MAP_IDX(width,index_x,index_y)] = temp_elevation;
                        }
                    }
                }

                // begin obstacle detection
                // clear temp_data
                temp_data = std::vector<int16_t>(width * height, (int16_t)unknown_elevation);
                CurrentMap=cv::Mat::zeros(height,width,CV_8UC1);
                int i;
                int filtered_cell, filtered_cell_x, filtered_cell_y,filtered_cell_xy,filtered_cell_yx,
                        filtered_cell_left,filtered_cell_right,filtered_cell_up,filtered_cell_down,filtered_cell_upleft,filtered_cell_downleft,
                             filtered_cell_upright,filtered_cell_downright;
                for (int index_y = M; index_y < (int)(width-M); ++index_y)
                {
                    for (int index_x = 0; index_x < (int)(height-2*M); ++index_x)
                    {
                        x_unknown = false;
                        y_unknown = false;
                        xy_unknown=false;
                        yx_unknown=false;
                        // 滤除未知点
                        if(elevation_data[MAP_IDX(width,index_x,index_y)] == unknown_elevation)
                            continue;
                        // 边缘提取
                        i = 1;
                        while((elevation_data[MAP_IDX(width,index_x+i,index_y)] == unknown_elevation)&&(i < m))
                        {
                            i++;
                        }
                        if(i == m) x_unknown = true;
                        else filtered_cell_up = elevation_data[MAP_IDX(width,index_x+i,index_y)];

                        i = 1;
                        while((elevation_data[MAP_IDX(width,index_x-i,index_y)] == unknown_elevation)&&(i < m))
                        {
                            i++;
                        }
                        if(i == m) x_unknown = true;
                        else filtered_cell_down = elevation_data[MAP_IDX(width,index_x-i,index_y)];
                        i = 1;
                        while((elevation_data[MAP_IDX(width,index_x,index_y+i)] == unknown_elevation)&&(i < m))
                        {
                            i++;
                        }
                        if(i == m) y_unknown = true;
                        else filtered_cell_left = elevation_data[MAP_IDX(width,index_x,index_y+i)];

                        i = 1;
                        while((elevation_data[MAP_IDX(width,index_x,index_y-i)] == unknown_elevation)&&(i < m))
                        {
                            i++;
                        }
                        if(i == m) y_unknown = true;
                        else filtered_cell_right = elevation_data[MAP_IDX(width,index_x,index_y-i)];

                        i = 1;
                        while((elevation_data[MAP_IDX(width,index_x-i,index_y-i)] == unknown_elevation)&&(i < m))
                        {
                            i++;
                        }
                        if(i == m) xy_unknown = true;
                        else filtered_cell_downright= elevation_data[MAP_IDX(width,index_x-i,index_y-i)];

                        i = 1;
                        while((elevation_data[MAP_IDX(width,index_x+i,index_y-i)] == unknown_elevation)&&(i < m))
                        {
                            i++;
                        }
                        if(i == m) yx_unknown = true;
                        else filtered_cell_upright = elevation_data[MAP_IDX(width,index_x+i,index_y-i)];

                        i = 1;
                        while((elevation_data[MAP_IDX(width,index_x-i,index_y+i)] == unknown_elevation)&&(i < m))
                        {
                            i++;
                        }
                        if(i == m) yx_unknown = true;
                        else filtered_cell_downleft = elevation_data[MAP_IDX(width,index_x-i,index_y+i)];

                        i = 1;
                        while((elevation_data[MAP_IDX(width,index_x+i,index_y+i)] == unknown_elevation)&&(i < m))
                        {
                            i++;
                        }
                        if(i == m) xy_unknown = true;
                        else filtered_cell_upleft = elevation_data[MAP_IDX(width,index_x+i,index_y+i)];

                        if(IsDownhill){
                            //以下是只检测上坡，不检测下坡
                            if(x_unknown || (filtered_cell_up<filtered_cell_down))
                                filtered_cell_x=-1;
                            else
                                filtered_cell_x = filtered_cell_up-filtered_cell_down;
                            if(xy_unknown || (filtered_cell_upleft<filtered_cell_downright))
                                filtered_cell_xy=-1;
                            else
                                filtered_cell_xy=filtered_cell_upleft-filtered_cell_downright;
                            if(yx_unknown || (filtered_cell_upright<filtered_cell_downleft))
                                filtered_cell_yx=-1;
                            else
                                filtered_cell_yx=filtered_cell_upright-filtered_cell_downleft;
                            if(index_y >= width_half){
                                if(y_unknown || (filtered_cell_left<filtered_cell_right))
                                    filtered_cell_y=-1;
                                else
                                    filtered_cell_y = filtered_cell_left-filtered_cell_right;
                            }
                            else{
                                if(y_unknown || (filtered_cell_left>filtered_cell_right))
                                    filtered_cell_y=-1;
                                else
                                    filtered_cell_y = filtered_cell_right-filtered_cell_left;
                            }
                        }
                        else{
                            //以下是所有路沿都检测
                            if(x_unknown)
                                filtered_cell_x=-1;
                            else
                                filtered_cell_x = abs(filtered_cell_up-filtered_cell_down);
                            if(y_unknown)
                                filtered_cell_y=-1;
                            else
                                filtered_cell_y = abs(filtered_cell_left-filtered_cell_right);
                            if(xy_unknown)
                                filtered_cell_xy=-1;
                            else
                                filtered_cell_xy=abs(filtered_cell_upleft-filtered_cell_downright);
                            if(yx_unknown)
                                filtered_cell_yx=-1;
                            else
                                filtered_cell_yx=abs(filtered_cell_downleft-filtered_cell_upright);
                        }

                        /*if(x_unknown || (filtered_cell_up<filtered_cell_down))
                            filtered_cell_x=-1;
                        else
                            filtered_cell_x = filtered_cell_up-filtered_cell_down;
                        if(xy_unknown || (filtered_cell_upleft<filtered_cell_downright))
                            filtered_cell_xy=-1;
                        else
                            filtered_cell_xy=filtered_cell_upleft-filtered_cell_downright;
                        if(yx_unknown || (filtered_cell_upright<filtered_cell_downleft))
                            filtered_cell_yx=-1;
                        else
                            filtered_cell_yx=filtered_cell_upright-filtered_cell_downleft;
                        if(index_y >= width_half){
                            if(y_unknown || (filtered_cell_left<filtered_cell_right))
                                filtered_cell_y=-1;
                            else
                                filtered_cell_y = filtered_cell_left-filtered_cell_right;
                        }
                        else{
                            if(y_unknown || (filtered_cell_left>filtered_cell_right))
                                filtered_cell_y=-1;
                            else
                                filtered_cell_y = filtered_cell_right-filtered_cell_left;

                        }*/

                        filtered_cell=filtered_cell_x;
                        if(filtered_cell_y > filtered_cell)
                            filtered_cell = filtered_cell_y;
                        if(filtered_cell_xy > filtered_cell)
                            filtered_cell = filtered_cell_xy;
                        if(filtered_cell_yx > filtered_cell)
                            filtered_cell = filtered_cell_yx;

                        if(filtered_cell > max_grad)
                        {
                            //temp_data[MAP_IDX(width,index_x,index_y)] = 0;
                            int countflag=0;
                            if(isFirstMap>0) {
                                if(index_x<((max_observable_distance-2)/resolution_xy) && index_y<(width_half+12) && index_y >(width_half-12)){
                                    for(int i=-4;i<5;i++){
                                        for(int j=-4;j<5;j++){
                                            if(last_temp_data[MAP_IDX(width,index_x+i,index_y+j)]==0) countflag++;
                                        }
                                    }
                                    if(countflag>=2){
                                        temp_data[MAP_IDX(width,index_x,index_y)] = 0;


                                       /* CurrentMap.at<char>(height-index_x,width-index_y)=255;
                                        point.x=index_x*resolution_xy;
                                        point.y=(index_y-width_half)*resolution_xy;
                                        point.z=0.5;
                                        obstacle_points.points.push_back(point);*/

                                    }
                                    countflag=0;
                                }
                                else{
                                    temp_data[MAP_IDX(width,index_x,index_y)] = 0;

                                    /*CurrentMap.at<char>(height-index_x,width-index_y)=255;
                                    point.x=index_x*resolution_xy;
                                    point.y=(index_y-width_half)*resolution_xy;
                                    point.z=0.5;
                                    obstacle_points.points.push_back(point);*/
                                }
                            }
                            else{
                                temp_data[MAP_IDX(width,index_x,index_y)] = 0;

                               /* CurrentMap.at<char>(height-index_x,width-index_y)=255;
                                point.x=index_x*resolution_xy;
                                point.y=(index_y-width_half)*resolution_xy;
                                point.z=0.5;
                                obstacle_points.points.push_back(point);*/
                            }
            //                    point.x=index_x*resolution_xy;
            //                    point.y=(index_y-width_half)*resolution_xy;
            //                    point.z=0.5;
            //                    obstacle_points.points.push_back(point);
                        }
                    }
                }
                last_temp_data.assign(temp_data.begin(),temp_data.end());


                // Connected component filter
                if(1)
                {
                    int region_label = 0;
                    int max_label = 99;
                    int region_size[100] = {0};
                    Eigen::Vector2i xy;
                    Eigen::Vector2i t;
                    std::queue<Eigen::Vector2i> q;
                    for (int index_y = M; index_y < (int)(width-M); ++index_y)
                    {
                        for (int index_x = 0; index_x < (int)(height-2*M); ++index_x)
                        {
                            if(temp_data[MAP_IDX(width,index_x,index_y)] == 0)
                            {
                                region_label++;
                                if(region_label>max_label)
                                {
                                    ROS_ERROR("Label over %d !,now is %d !",max_label,region_label);
                                    break;
                                }
                                region_size[region_label]++;
                                temp_data[MAP_IDX(width,index_x,index_y)] = region_label;
                                xy(0) = index_x;
                                xy(1) = index_y;
                                q.push(xy);
                                while(!q.empty())
                                {
                                    xy = q.front();
                                    q.pop();
                                    for(int x=xy(0)-1;x<=xy(0)+1;x++)
                                    {
                                        for(int y=xy(1)-1;y<=xy(1)+1;y++)
                                        {
                                            if(temp_data[MAP_IDX(width,x,y)] == 0)
                                            {
                                                temp_data[MAP_IDX(width,x,y)] = region_label;
                                                region_size[region_label]++;
                                                t(0) = x;
                                                t(1) = y;
                                                q.push(t);
                                            }
                                        }
                                    }
                                }
        //                        ROS_ERROR("region_label = %d,region_size = %d !",region_label,region_size[region_label]);
                            }
                        }
                    }
                    //以下未采用连通域滤波，采用珊格统计滤波

                    /*int NearestLine=0.52;
                    int NearestLineCell;
                    NearestLineCell=round(NearestLine/resolution_xy);
                    float LeftY,RightY;
                    int ZeroCount;
                    for (int index_y = M; index_y < (int)(width-M); ++index_y)
                    {
                        for (int index_x = 0; index_x < (int)(height-2*M); ++index_x)
                        {
                            LeftY=(float(index_x)+float(M)-1.18/resolution_xy)*tan(fov*PI/360.0)+float(NearestLineCell)+float(width_half);
                            RightY=-(float(index_x)+float(M)-1.18/resolution_xy)*tan(fov*PI/360.0)-float(NearestLineCell)+float(width_half);
                            if(index_y>LeftY || index_y<RightY)
                                continue;

                            if(temp_data[MAP_IDX(width,index_x,index_y)] == 0)
                            {
                                ZeroCount=1;
                                for(int x=index_x-filter_radius;x<=index_x+filter_radius;++x){
                                    for(int y=index_y-filter_radius;y<=index_y+filter_radius;++y){
                                        if(temp_data[MAP_IDX(width,x,y)]==0)
                                            ZeroCount++;
                                    }
                                }
                                if(ZeroCount>=connection_filter_threshold){
                                    point.x=index_x*resolution_xy;
                                    point.y=(index_y-width_half)*resolution_xy;
                                    point.z=0.5;
                                    obstacle_points.points.push_back(point);
                                }
                            }
                        }
                    }*/


                    // visulization module
                    // Converting obstacles to pointcloud

                    //CurrentMap=cv::Mat::zeros(height,width,CV_8UC1);
                    if(1)
                    {
                        for (int index_y = M; index_y < (int)(width-M); ++index_y)
                        {
                            for (int index_x = 0; index_x < (int)(height-2*M); ++index_x)
                            {
                                if(temp_data[MAP_IDX(width,index_x,index_y)] == unknown_elevation) continue;
                                if(region_size[temp_data[MAP_IDX(width,index_x,index_y)]] < connection_filter_threshold) continue;
                                CurrentMap.at<char>(height-index_x,width-index_y)=255;
                                point.x=index_x*resolution_xy;
                                point.y=(index_y-width_half)*resolution_xy;
                                point.z=0.5;
                                if (isnan(point.x) || isnan(point.y) || isnan(point.z))
                                    continue;

                                obstacle_points.points.push_back(point);
                            }
                        }
                    }
                }


                static vector< vector<Point> > LastContours,CurrentContours;
                static vector<Moments> LastMo;
                static vector<Point> LastPo;


                //cv::namedWindow("CurrentMap");
                cv::namedWindow("contours");

                //cv::namedWindow("out");
                Mat element = getStructuringElement(MORPH_RECT, Size(3, 3));
                cv::Mat out;

                if(isFirstMap==0){//如果是第一帧图像，则如下处理
                    t0=chrono::steady_clock::now();
                    //cv::imshow("CurrentMap", CurrentMap);
                    cv::dilate(CurrentMap,out, element);
                    //cv::imshow("out", out);
                    cv::findContours(out,CurrentContours,CV_RETR_EXTERNAL,CV_CHAIN_APPROX_NONE);
                    cv::Mat result(CurrentMap.size(),CV_8UC3,Scalar(0,0,0));
                    cv::drawContours(result,CurrentContours,-1,Scalar(255,255,255),2);
                    vector<Moments> CurrentMo;
                    vector<Point> CurrentPo;

                    for( int i = 0; i < CurrentContours.size(); i++ )
                    {
                            CurrentMo.push_back(cv::moments(CurrentContours[i],false));//求当前图像各轮廓的轮廓距
                            LastMo.push_back(cv::moments(CurrentContours[i],false));//求上一帧图像各轮廓的轮廓距
                            CurrentPo.push_back(Point2d(int(CurrentMo[i].m10/CurrentMo[i].m00),int(CurrentMo[i].m01/CurrentMo[i].m00)));//求当前图像各轮廓质心
                            LastPo.push_back(Point2d(int(CurrentMo[i].m10/CurrentMo[i].m00),int(CurrentMo[i].m01/CurrentMo[i].m00)));//求上一帧图像各轮廓质心
                            cv::circle(result,CurrentPo[i],2,Scalar(255,0,0),1);
                    }
                    //CurrentMo.clear();
                    //CurrentPo.clear();
                    vector<Moments>().swap(CurrentMo);
                    vector<Point>().swap(CurrentPo);
                    //ROS_ERROR("the currentMo size is: %d",CurrentMo.size());
                    cv::imshow("contours",result);
                    LastContours.assign(CurrentContours.begin(),CurrentContours.end());
                    isFirstMap=1;

                }
                else{
                    t1=chrono::steady_clock::now();
                    chrono::duration<double> time_used=chrono::duration_cast<chrono::duration<double>>(t1-t0);
                    timeT=time_used.count();                    
                    t0=t1;                   
                    //cv::imshow("CurrentMap", CurrentMap);
                    cv::dilate(CurrentMap,out, element);
                    //cv::imshow("out", out);
                    cv::findContours(out,CurrentContours,CV_RETR_EXTERNAL,CV_CHAIN_APPROX_NONE);
                    cv::Mat result(CurrentMap.size(),CV_8UC3,Scalar(0,0,0));
                    cv::drawContours(result,CurrentContours,-1,Scalar(255,255,255),2);

                    vector<Moments> CurrentMo;
                    vector<Point> CurrentPo;
                    for( int i = 0; i < CurrentContours.size(); i++ )
                    {
                            CurrentMo.push_back(cv::moments(CurrentContours[i],false));
                            CurrentPo.push_back(Point2d(int(CurrentMo[i].m10/CurrentMo[i].m00),int(CurrentMo[i].m01/CurrentMo[i].m00)));
                            cv::circle(result,CurrentPo[i],2,Scalar(255,0,0),1);


                            double dist=0,min_dist=40000;
                            double match_result=0;
                            int index_j=0;
                            if(LastContours.size()<1) continue;
                            for(int j=0;j<LastContours.size();j++){
                                dist=(LastPo[j].x-CurrentPo[i].x)*(LastPo[j].x-CurrentPo[i].x)+(LastPo[j].y-CurrentPo[i].y)*(LastPo[j].y-CurrentPo[i].y);
                                if(dist<=min_dist){
                                    min_dist=dist;
                                    index_j=j;
                                }
                            }                          
                            match_result = cv::matchShapes(CurrentContours[i], LastContours[index_j],CV_CONTOURS_MATCH_I1,0.0);
                            if(min_dist<=30){
                                if(match_result>0.7) continue;
                                float speed=0.0,speed_x=0.0,speed_y=0.0;
                                speed=sqrt(min_dist)*resolution_xy/timeT;
                                if(speed<=0.8) continue;
                                speed_x=fabs(LastPo[index_j].x-CurrentPo[i].x)*resolution_xy/timeT;
                                speed_y=fabs(LastPo[index_j].y-CurrentPo[i].y)*resolution_xy/timeT;                               
                                cv::line(result,CurrentPo[i],Point(CurrentPo[i].x+int(3*speed*(CurrentPo[i].x-LastPo[index_j].x)), CurrentPo[i].y+int(3*speed*(CurrentPo[i].y-LastPo[index_j].y))),Scalar(0,0,255),2);
                                char tam[100];
                                sprintf(tam, "speed: %0.2f",speed);
                                putText(result, tam, Point(CurrentPo[i].x, CurrentPo[i].y), FONT_HERSHEY_SIMPLEX, 0.4, cvScalar(0,255,0),1);
                                po_person.position.x=(height-CurrentPo[i].x)*resolution_xy;
                                po_person.position.y=(width_half-CurrentPo[i].y)*resolution_xy;
                                po_person.position.z=0.5;
                                po_person.velocity.x=speed_x;
                                po_person.velocity.y=speed_y;
                                po_person.velocity.z=0.0;
                                po_person.name="PoPerson";
                                po_person.reliability=0.70;
                                po_people.people.push_back(po_person);

                            }
                    }

                    LastPo.clear();
                    LastMo.clear();
                    LastPo.assign(CurrentPo.begin(),CurrentPo.end());
                    LastMo.assign(CurrentMo.begin(),CurrentMo.end());
                    LastContours.clear();
                    LastContours.assign(CurrentContours.begin(),CurrentContours.end());
                    CurrentContours.clear();
                    //cv::namedWindow("CurrentMap");
                    //cv::imshow("CurrentMap", CurrentMap);

                    cv::imshow("contours",result);

                }
                cv::waitKey(1);

                LastMap=CurrentMap.clone();
                //增加clean points
                /*if(0)
                {
                    for (double y = -5.0; y < 5.0; y+=0.03)
                    {
                        point.y = y;
                        point.x = 11.0;
                        point.z=0.5;
                        obstacle_points.points.push_back(point);
                    }
                }*/
                //发布points

                obstacle_points.header.frame_id = local_map_frame_id;
                obstacle_points.header.stamp = pointcloud2_sensor_msg->header.stamp;
                po_people.header.frame_id=local_map_frame_id;
                po_people.header.stamp=pointcloud2_sensor_msg->header.stamp;


                pub_points.publish(obstacle_points);
                //pub_people.publish(po_people);
            }
        }

    /// sysMessageCallback This function listen to system messages
    /**
    * \param [in] string parameter contains system messages, like "reset"
    */

};

int main(int argc, char **argv)
{
  ros::init(argc, argv, "pointcloud_obstacle");

  // Shared parameters to be propagated to nodelet private namespaces
  PointcloudObstacle PO;

  ros::spin();
  return 0;
}
